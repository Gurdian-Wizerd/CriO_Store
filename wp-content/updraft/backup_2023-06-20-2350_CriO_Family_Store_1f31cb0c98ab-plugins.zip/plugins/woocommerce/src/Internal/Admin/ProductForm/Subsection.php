<?php
/**
 * Handles product form SubSection related methods.
 */

namespace Automattic\WooCommerce\Internal\Admin\ProductForm;

/**
 * SubSection class.
 */
class Subsection extends Component {}
